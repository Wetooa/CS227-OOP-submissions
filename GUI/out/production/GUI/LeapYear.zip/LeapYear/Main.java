package LeapYear;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends  JFrame {
    private JButton btnCheckYear;
    private JTextField tfYear;
    private JPanel jpanel;

    public Main() {
        btnCheckYear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane op = new JOptionPane();
                try {
                    int year =  Integer.parseInt(tfYear.getText());
                    op.showMessageDialog(null, isLeapYear(year) ? "Leap Year" : "Not a leap year");
                } catch (Exception exception) {
                    op.showMessageDialog(null, "Invalid year");
                }
            }

            public boolean isLeapYear(int year) {
                return year % 4 == 0 && year % 100 != 0 || year % 400 == 0;
            }
        });
    }

    public static void main(String[] args) {
        Main app = new Main();

        app.setContentPane(app.jpanel);
        app.setSize(1000, 600);
        app.setLocationRelativeTo(null);
        app.setDefaultCloseOperation(EXIT_ON_CLOSE);
        app.setTitle("Leap Year Checker");
        app.setVisible(true);
    }

}
